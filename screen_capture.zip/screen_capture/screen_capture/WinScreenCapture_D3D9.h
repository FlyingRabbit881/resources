/*************************************************************************************************/
/* Project: Screen capture server                                                                */
/* Author: @aviloria (GitHub)                                                                    */
/*-----------------------------------------------------------------------------------------------*/
/* Copyleft license                                                                              */
/*    YOU ARE ALLOWED TO FREELY DISTRIBUTE COPIES AND MODIFIED VERSIONS OF THIS WORK WITH        */
/*    THE STIPULATION THAT THE SAME RIGHTS BE PRESERVED IN DERIVATIVE WORKS CREATED LATER.       */
/*************************************************************************************************/
//-------------------------------------------------------------------------------------------------
#ifndef __WINSCREENCAPTURE_D3D9_H__
#define __WINSCREENCAPTURE_D3D9_H__
//-------------------------------------------------------------------------------------------------
#include <d3d9.h>
#include <stdint.h>
#include <stdio.h>
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------

/**
 * Screen capture class for capturing using Direct3D 9
 */
class WinScreenCapture_D3D9
{
public:
	WinScreenCapture_D3D9(const TCHAR *strDisplayDevice=NULL);
	~WinScreenCapture_D3D9();

	BOOL getCurrentScreenSize(UINT &nSizeX, UINT &nSizeY) ;

	BOOL captureScreenRect(uint8_t *buffer, int w, int h);

private:
	UINT               _nAdapterId;
	IDirect3D9        *_pD3D;
	IDirect3DDevice9  *_pDevice;
	IDirect3DSurface9 *_pSurface;
	int width_, height_;
};
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
#endif // __WINSCREENCAPTURE_D3D9_H__
//-------------------------------------------------------------------------------------------------
