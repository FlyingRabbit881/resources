#include <iostream>
using namespace std;
#include "WinScreenCapture_D3D9.h"
extern "C" {
#include "libavcodec/avcodec.h"
#include "libavutil/opt.h"
#include "libavutil/time.h"
#include "libavutil/frame.h"
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
#include <libavformat/avformat.h>
}
#include <thread>
#include <chrono>
#include <mutex>
#include <list>
#include <queue>
int iFrame = 0;
UINT w, h;
bool scale_inited = false;
AVFrame           *pFrame = NULL;
AVFrame           *pFrameRGB = NULL;
int               numBytes;
int               yuvBytes;
uint8_t           *buffer = NULL;
uint8_t           *yuv_buffer;
struct SwsContext *sws_ctx = NULL;
int fps = 25;

class FramePool
{
public:
	FramePool(int width, int height, int size)
	{
		for (int i = 0; i < size; ++i)
		{
			// Allocate video frame
			AVFrame* pFrame = av_frame_alloc();

			// Determine required buffer size and allocate buffer
			int yuvBytes = avpicture_get_size(AV_PIX_FMT_YUV420P, width, height);
			uint8_t* yuv_buffer = (uint8_t *)av_malloc(yuvBytes * sizeof(uint8_t));

			// Assign appropriate parts of buffer to image planes in pFrameRGB
			// Note that pFrameRGB is an AVFrame, but AVFrame is a superset
			// of AVPicture
			//avpicture_fill((AVPicture *)pFrame, yuv_buffer, AV_PIX_FMT_YUV420P, width, height);
			av_image_fill_arrays(pFrame->data, pFrame->linesize, yuv_buffer, AV_PIX_FMT_YUV420P, width, height, 1);
			frames_.push_back(pFrame);
		}
	}
	~FramePool()
	{

	}
	AVFrame* Get()
	{
		std::lock_guard<std::mutex> lk(mutex_);
		if (frames_.empty())
			return nullptr;
		AVFrame* f = frames_.front();
		frames_.pop_front();
		return f;
	}
	void Return(AVFrame* f)
	{
		std::lock_guard<std::mutex> lk(mutex_);
		frames_.push_back(f);
	}
private:
	std::list<AVFrame*> frames_;
	std::mutex mutex_;
};

class FrameQueue
{
public:
	void Enqueue(AVFrame* f)
	{
		{
			std::lock_guard<std::mutex> lk(mutex_);
			frames_.push(f);
		}
		cv_.notify_one();
	}
	AVFrame* Dequeue()
	{
		std::unique_lock <std::mutex> lk(mutex_);
		cv_.wait(lk, [this]() { return !frames_.empty(); });
		AVFrame* f = frames_.front();
		frames_.pop();
		return f;
	}

private:
	std::queue<AVFrame*> frames_;
	std::mutex mutex_;
	std::condition_variable cv_;
};
FramePool pool(1280, 720, 100);
FrameQueue frame_q;
void EncodeThread()
{
	AVCodec *codec = avcodec_find_encoder(AV_CODEC_ID_H264);
	if (!codec) {
		return;
	}

	AVCodecContext* enc_cxt = avcodec_alloc_context3(codec);
	if (!enc_cxt) {
		return;
	}
	enc_cxt->width = 1280;
	enc_cxt->height = 720;
	enc_cxt->time_base.den = fps;
	enc_cxt->time_base.num = 1;
	enc_cxt->gop_size = fps;
	enc_cxt->max_b_frames = 0;
	enc_cxt->pix_fmt = AV_PIX_FMT_YUV420P;
	enc_cxt->profile = FF_PROFILE_H264_BASELINE;
	enc_cxt->level = 30;
	//enc_cxt_->slices = 1;
	//enc_cxt_->thread_type = FF_THREAD_FRAME;

	av_opt_set(enc_cxt->priv_data, "preset", "superfast", 0);
	av_opt_set(enc_cxt->priv_data, "tune", "zerolatency", 0);

	int bitrate = 2000000;
	if (1)
	{
		enc_cxt->bit_rate = bitrate;
		enc_cxt->rc_max_rate = bitrate;
		enc_cxt->rc_min_rate = bitrate; // VBV maxrate specified, but no bufsize, ignored   
		//enc_cxt->rc_buffer_size = bitrate / 2;
		enc_cxt->rc_buffer_size = 2 * bitrate;
	}
	else
	{
#if 0
		char crf_string[50];
		sprintf_s(crf_string, "crf=%f", quality_);
		av_opt_set(enc_cxt_->priv_data, "x264opts", crf_string, 0);  //crf
		//av_opt_set(enc_cxt_->priv_data, "crf",crf_string,0);  //crf
		enc_cxt_->rc_max_rate = bit_rate_;
		enc_cxt_->rc_buffer_size = bit_rate_ / 2;
#endif

		char crf_string[50];
		sprintf_s(crf_string, "%f", 23);
		av_opt_set(enc_cxt->priv_data, "crf", crf_string, 0);
		enc_cxt->rc_max_rate = bitrate;
		enc_cxt->rc_buffer_size = bitrate / 2;
#if 0
		char x264params[1024];
		sprintf_s(x264params, "crf=%f:vbv-maxrate=%d:vbv-bufsize=%d", quality_, bit_rate_, bit_rate_ / 2);
		av_opt_set(enc_cxt_->priv_data, "x264-params", x264params, 0);  //crf
#endif
	}

	enc_cxt->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
	/* open it */
	if (avcodec_open2(enc_cxt, codec, NULL) < 0) {
		return;
	}
	int ret;

	const char* filename = "rtmp://localhost/live/stream";
	AVFormatContext* oc;
	/* allocate the output media context */
	avformat_alloc_output_context2(&oc, NULL, "flv", filename);
	if (!oc) {
		printf("Could not deduce output format from file extension: using MPEG.\n");
		avformat_alloc_output_context2(&oc, NULL, "mpeg", filename);
	}

	AVOutputFormat *fmt = oc->oformat;
	fmt->video_codec = AV_CODEC_ID_H264;
	//fmt->audio_codec = AV_CODEC_ID_AAC;
	AVStream* st = avformat_new_stream(oc, NULL);
	if (!st) {
		fprintf(stderr, "Could not allocate stream\n");
		exit(1);
	}
	st->id = oc->nb_streams - 1;
	st->time_base = enc_cxt->time_base;
	/* copy the stream parameters to the muxer */
	ret = avcodec_parameters_from_context(st->codecpar, enc_cxt);
	if (ret < 0) {
		fprintf(stderr, "Could not copy the stream parameters\n");
		exit(1);
	}
	/* open the output file, if needed */
	if (!(fmt->flags & AVFMT_NOFILE)) {
		ret = avio_open(&oc->pb, filename, AVIO_FLAG_WRITE);
		if (ret < 0) {
			return;
		}
	}
	AVDictionary *opt = NULL;
	/* Write the stream header, if any. */
	ret = avformat_write_header(oc, &opt);
	if (ret < 0) {
		return;
	}
	AVPacket* pkt = av_packet_alloc();
	int64_t pre_pts = 0;
#if 1
	while (1)
	{
		AVFrame* frame = frame_q.Dequeue();
		int64_t pts = frame->pts;
		printf("%d\n", pts - pre_pts);
		pre_pts = pts;
		frame->pict_type = AV_PICTURE_TYPE_NONE;
		ret = avcodec_send_frame(enc_cxt, frame);
		if (ret < 0) {
			fprintf(stderr, "Error sending a frame for encoding\n");
			exit(1);
		}

		while (ret >= 0) {
			ret = avcodec_receive_packet(enc_cxt, pkt);
			if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
				break;
			else if (ret < 0) {
				fprintf(stderr, "Error during encoding\n");
				exit(1);
			}
			/*	static FILE* fp = fopen("1.264", "wb");
				fwrite(pkt->data, 1, pkt->size, fp);*/
			ret = av_interleaved_write_frame(oc, pkt);
			av_packet_unref(pkt);
		}
		pool.Return(frame);
	}
#endif

	/*while (1)
	{
		AVFrame* frame = frame_q.Dequeue();
		static FILE* fp = fopen("x.yuv", "wb");
		fwrite(frame->data[0], 1, frame->width * frame->height * 3 / 2, fp);
		pool.Return(frame);
	}*/
}
class AdaptiveDelay
{
public:
	void Delay(int ms)
	{
		if (first_)
		{
			first_ = false;
			target_time_ = std::chrono::high_resolution_clock::now();
			return;
		}
		target_time_ += std::chrono::milliseconds{ ms };
		auto now = std::chrono::high_resolution_clock::now();
		if (target_time_ > now)
		{
			std::this_thread::sleep_for(target_time_ - now);
		}
	}
private:
	std::chrono::high_resolution_clock::time_point target_time_{ };
	bool first_ = true;
};
int main()
{
	std::thread t(EncodeThread);
	WinScreenCapture_D3D9 cap;
	
	//cap.getCurrentScreenSize(w, h);
	w = 1280, h = 720;
	int width = w, height = h;
	uint8_t* buf = new uint8_t[w * h * 4];
	int64_t pre_pts = 0;
	pFrameRGB = av_frame_alloc();
	// Determine required buffer size and allocate buffer
	int numBytes = avpicture_get_size(AV_PIX_FMT_RGBA, width, height);
	uint8_t* buffer = (uint8_t *)av_malloc(numBytes * sizeof(uint8_t));
	av_image_fill_arrays(pFrameRGB->data, pFrameRGB->linesize, buffer, AV_PIX_FMT_RGBA, width, height, 1);
	// initialize SWS context for software scaling
	sws_ctx = sws_getContext(width, height, AV_PIX_FMT_BGRA, width, height, AV_PIX_FMT_YUV420P, SWS_BILINEAR, NULL, NULL, NULL);
	int size = width * height * 4;
	AdaptiveDelay delayer;
	while (1)
	{
		delayer.Delay(1000/fps);
		cap.captureScreenRect(buf, 1280, 720);
		uint8_t *rgba = pFrameRGB->data[0];
		memcpy(rgba, buf, size);
		AVFrame* pFrame = pool.Get();
		if (pFrame)
		{
			sws_scale(sws_ctx, (uint8_t const * const *)pFrameRGB->data, pFrameRGB->linesize, 0, height, pFrame->data, pFrame->linesize);
			pFrame->pts = av_gettime() / 1000;
			pFrame->width = width;
			pFrame->height = height;
			pFrame->format = AV_PIX_FMT_YUV420P;
			frame_q.Enqueue(pFrame);
		}
		else
			printf("no free frame\n");

	}
	return 0;
}