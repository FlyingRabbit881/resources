#include <iostream>
#include <thread>
#include <mutex>
#include <queue>
#include <atomic>
#include "D3DRender.h"
#include "CircularBuffer.h"
#include "SDLARender.h"
extern "C" {
#include "sdl2/SDL.h"
#include "libavcodec/avcodec.h"
#include "libavutil/opt.h"
#include "libavutil/time.h"
#include "libavutil/frame.h"
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
#include <libavformat/avformat.h>
};
#undef main

const char* url = "rtmp://localhost/live/stream";
static AVFormatContext *fmt_ctx = NULL;
static AVCodecContext *video_dec_ctx = NULL, *audio_dec_ctx;
static int width, height;
int video_stream_index = -1, audio_stream_index = -1;
int channels = 2;
HWND hwnd_;
CSDLARender *audio_dev_;
std::atomic<int64_t> audio_clock{ 0 };

class PacketQueue
{
public:
	void Enqueue(AVPacket* pkt)
	{
		AVPacket* tmp = av_packet_alloc();
		av_packet_ref(tmp, pkt);
		{
			std::lock_guard<std::mutex> lk(mutex_);
			pkts_.push(tmp);
		}
		cv_.notify_one();
	}
	AVPacket* Dequeue()
	{
		std::unique_lock <std::mutex> lk(mutex_);
		cv_.wait(lk, [this]() { return !pkts_.empty(); });
		AVPacket* pkt = pkts_.front();
		pkts_.pop();
		return pkt;
	}
private:
	std::queue<AVPacket*> pkts_;
	std::mutex mutex_;
	std::condition_variable cv_;
};
class FrameQueue
{
public:
	void Enqueue(AVFrame* f)
	{
		AVFrame* tmp = av_frame_alloc();
		av_frame_ref(tmp, f);
		{
			std::lock_guard<std::mutex> lk(mutex_);
			frames_.push(tmp);
		}
		cv_.notify_one();
	}
	AVFrame* Dequeue()
	{
		std::unique_lock <std::mutex> lk(mutex_);
		cv_.wait(lk, [this]() { return !frames_.empty(); });
		AVFrame* f = frames_.front();
		frames_.pop();
		return f;
	}
	bool empty()
	{
		std::lock_guard<std::mutex> lk(mutex_);
		return frames_.empty();
	}
private:
	std::queue<AVFrame*> frames_;
	std::mutex mutex_;
	std::condition_variable cv_;
};

static constexpr int kSamplesPerFrame = 1024;
class SampleQueue
{
public:
	SampleQueue(int channels) :channels_(channels)
	{
		bytes_per_frame_ = sizeof(short) * kSamplesPerFrame * channels_;
		p_buffer_ = new CircularBuffer((sizeof(FrameInfo) + bytes_per_frame_) * 9);
	}
	~SampleQueue()
	{
		delete p_buffer_;
	}
	bool Enqueue(void* data, size_t size, int64_t pts)
	{
		FrameInfo info;
		int total_size = sizeof(info) + size;
		info.pts = pts;
		info.size = size;
		{
			std::lock_guard<std::mutex> lk(mutex_);
			if (p_buffer_->available() < total_size)
				return false;

			p_buffer_->write((const char*)&info, sizeof(info));
			p_buffer_->write((const char*)data, size);
		}

		cv_.notify_one();
		return true;
	}
	bool Dequeue(void *data, size_t *size, int64_t *pts)
	{
		FrameInfo info;
		{
			std::unique_lock <std::mutex> lk(mutex_);
			cv_.wait(lk, [this]() { return p_buffer_->size() != 0; });
			p_buffer_->read((char*)&info, sizeof(info));
			p_buffer_->read((char*)data, info.size);
		}

		*size = info.size;
		*pts = info.pts;
		return true;
	}

private:
	struct FrameInfo
	{
		int size;
		int64_t pts;
	};
	int channels_;
	int bytes_per_frame_;
	CircularBuffer* p_buffer_;
	std::mutex mutex_;
	std::condition_variable cv_;
};

FrameQueue pictq;
SampleQueue *sampq;

PacketQueue videoq;
PacketQueue audioq;
constexpr AVRational timebase_ms = { 1, 1000 };

void RecvThread()
{
	AVPacket pkt;
	av_init_packet(&pkt);
	pkt.data = NULL;
	pkt.size = 0;
	/* read frames from the file */
	while (av_read_frame(fmt_ctx, &pkt) >= 0) {
		// check if the packet belongs to a stream we are interested in, otherwise
		// skip it
		if (pkt.stream_index == video_stream_index)
		{
			videoq.Enqueue(&pkt);
		}
		else if (pkt.stream_index == audio_stream_index)
		{
			audioq.Enqueue(&pkt);
		}
		av_packet_unref(&pkt);
	}

}
void AudioDecodeThread()
{
	AVPacket* pkt;
	AVFrame* frame = av_frame_alloc();
	int ret;
	uint8_t* pkt_buf = new uint8_t[1024 * 2 * 2];
	int channels = audio_dec_ctx->channels;
	int size = sizeof(short) * kSamplesPerFrame * channels;
	while (1)
	{
		pkt = audioq.Dequeue();
		// submit the packet to the decoder
		ret = avcodec_send_packet(audio_dec_ctx, pkt);
		if (ret < 0) {
			fprintf(stderr, "Error submitting a packet for decoding");
		}

		// get all the available frames from the decoder
		while (ret >= 0) {
			ret = avcodec_receive_frame(audio_dec_ctx, frame);
			if (ret < 0) {
				// those two return values are special and mean there is no output
				// frame available, but there were no errors during decoding
				if (ret == AVERROR_EOF || ret == AVERROR(EAGAIN))
					break;

				fprintf(stderr, "Error during decoding");
				break;
			}
			frame->pts = frame->best_effort_timestamp;
			frame->pts = av_rescale_q(frame->pts, fmt_ctx->streams[audio_stream_index]->time_base, timebase_ms);
			short* s16_samples = (short*)pkt_buf;
			for (int k = 0; k < kSamplesPerFrame; k++)
			{
				for (int c = 0; c < channels; c++)
				{
					float* samples = (float*)frame->extended_data[c];
					if (samples[k] > 1.0f)
						samples[k] = 1.0f;
					else if (samples[k] < -1.0f)
						samples[k] = -1.0f;

					s16_samples[k * channels + c] = (short)(samples[k] * 32767.0f);
				}
			}
			bool r = sampq->Enqueue(pkt_buf, size, frame->pts);
			if (r == false)
				printf("audio frame queue is full pts=%I64d\n", frame->pts);

			av_frame_unref(frame);
		}
		av_packet_free(&pkt);
	}
}

void VideoDecodeThread()
{
	int ret;
	AVFrame* frame = av_frame_alloc();
	while (1)
	{
		AVPacket* pkt = videoq.Dequeue();
		// submit the packet to the decoder
		ret = avcodec_send_packet(video_dec_ctx, pkt);
		if (ret < 0) {
			fprintf(stderr, "Error submitting a packet for decoding");
		}

		// get all the available frames from the decoder
		while (ret >= 0) {
			ret = avcodec_receive_frame(video_dec_ctx, frame);
			if (ret < 0) {
				// those two return values are special and mean there is no output
				// frame available, but there were no errors during decoding
				if (ret == AVERROR_EOF || ret == AVERROR(EAGAIN))
					break;

				fprintf(stderr, "Error during decoding");
				break;
			}
			frame->pts = frame->best_effort_timestamp;
			frame->pts = av_rescale_q(frame->pts, fmt_ctx->streams[video_stream_index]->time_base, timebase_ms);
			pictq.Enqueue(frame);

			av_frame_unref(frame);
		}
		av_packet_free(&pkt);
	}
}
int VideoRenderThread()
{
	D3DRender* renderer_ = new D3DRender();
	if (!renderer_->Initialize(hwnd_))
		return -1;


	int64_t pts = AV_NOPTS_VALUE;
	size_t size;
	AVFrame* frame = nullptr;
	for (;;)
	{
		

		if (pts != AV_NOPTS_VALUE)
		{
		}
		else
		{
			if (pictq.empty())
			{
				Sleep(1);
				continue;
			}
			else
			{
				frame = pictq.Dequeue();
				pts = frame->pts;
			}
		}

		bool render = false;
		{
#if 0
			if (sync_track_ && pts < sync_track_->clock() || sync_track_ == NULL)
				render = true;
#else
			if (1)
			{
				int64_t diff = pts - audio_clock;
				if (diff < 0 || diff > 10000)  //����10s����ʱ����쳣
					render = true;
			}
			else
			{
				render = true;
			}
#endif
		}

		if (render)
		{
			bool r = renderer_->DrawPicture(frame);
			if (!r)
				printf("draw failed\n");
			av_frame_free(&frame);
			pts = AV_NOPTS_VALUE;
		}



		/*	renderer_->DrawPicture(w, h, yuv_buffer);
			pts = AV_NOPTS_VALUE;*/
		Sleep(1);
	}
	delete renderer_;
	return 0;
}
void SDLAudioCallback(void *udata, uint8_t *stream, int len)
{
	size_t size;
	int64_t pts;
	sampq->Dequeue(stream, &size, &pts);
	audio_clock = pts;
}
int main()
{
	SDL_Window *window;                    // ����SDL_Windowָ��
	SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER);              // ��ʼ��SDL2ϵͳ
	
	
	/* open input file, and allocate format context */
	if (avformat_open_input(&fmt_ctx, url, NULL, NULL) < 0) {
		fprintf(stderr, "Could not open source file %s\n", url);
		getchar();
		return -1;
	}

	/* retrieve stream information */
	if (avformat_find_stream_info(fmt_ctx, NULL) < 0) {
		fprintf(stderr, "Could not find stream information\n");
		exit(1);
	}
	int ret = av_find_best_stream(fmt_ctx, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
	if (ret < 0) {
		fprintf(stderr, "Could not find %s stream in input file '%s'\n",
			av_get_media_type_string(AVMEDIA_TYPE_VIDEO), url);
		return ret;
	} 
	else
	{
		video_stream_index = ret;
	}
	ret = av_find_best_stream(fmt_ctx, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
	if (ret < 0) {
		fprintf(stderr, "Could not find %s stream in input file '%s'\n",
			av_get_media_type_string(AVMEDIA_TYPE_AUDIO), url);
		return ret;
	}
	else
	{
		audio_stream_index = ret;
	}
	
	// ��ʼ����Ƶ������
	AVStream* st = fmt_ctx->streams[video_stream_index];

	/* find decoder for the stream */
	AVCodec* dec = avcodec_find_decoder(st->codecpar->codec_id);
	if (!dec) {
		fprintf(stderr, "Failed to find %s codec\n",
			av_get_media_type_string(AVMEDIA_TYPE_VIDEO));
		return AVERROR(EINVAL);
	}

	/* Allocate a codec context for the decoder */
	video_dec_ctx = avcodec_alloc_context3(dec);

	/* Copy codec parameters from input stream to output codec context */
	if ((ret = avcodec_parameters_to_context(video_dec_ctx, st->codecpar)) < 0) {
		fprintf(stderr, "Failed to copy %s codec parameters to decoder context\n",
			av_get_media_type_string(AVMEDIA_TYPE_VIDEO));
		return ret;
	}

	/* Init the decoders */
	if ((ret = avcodec_open2(video_dec_ctx, dec, NULL)) < 0) {
		fprintf(stderr, "Failed to open %s codec\n",
			av_get_media_type_string(AVMEDIA_TYPE_VIDEO));
		return ret;
	}

	//��ʼ����Ƶ������
	st = fmt_ctx->streams[audio_stream_index];

	/* find decoder for the stream */
	dec = avcodec_find_decoder(st->codecpar->codec_id);
	if (!dec) {
		fprintf(stderr, "Failed to find %s codec\n",
			av_get_media_type_string(AVMEDIA_TYPE_AUDIO));
		return AVERROR(EINVAL);
	}

	/* Allocate a codec context for the decoder */
	audio_dec_ctx = avcodec_alloc_context3(dec);

	/* Copy codec parameters from input stream to output codec context */
	if ((ret = avcodec_parameters_to_context(audio_dec_ctx, st->codecpar)) < 0) {
		fprintf(stderr, "Failed to copy %s codec parameters to decoder context\n",
			av_get_media_type_string(AVMEDIA_TYPE_VIDEO));
		return ret;
	}

	/* Init the decoders */
	if ((ret = avcodec_open2(audio_dec_ctx, dec, NULL)) < 0) {
		fprintf(stderr, "Failed to open %s codec\n",
			av_get_media_type_string(AVMEDIA_TYPE_VIDEO));
		return ret;
	}
	
	// ����һ��Ӧ�ô���
	window = SDL_CreateWindow(
		"Play Live",                  // ����title
		SDL_WINDOWPOS_UNDEFINED,           // x
		SDL_WINDOWPOS_UNDEFINED,           // y
		video_dec_ctx->width,                               // ��
		video_dec_ctx->height,                               // ��
		SDL_WINDOW_OPENGL                  // flags - see below
	);
	// ��鴰���Ƿ񴴽��ɹ���������ɹ�window ΪNULL
	if (window == NULL) {
		// �������û�д����ɹ�������ĳ����Ѿ�û��ִ�еı�Ҫ�ˡ�
		printf("Could not create window: %s\n", SDL_GetError());
		return 1;
	}
	hwnd_ = FindWindow(NULL, "Play Live");
	if (hwnd_ == NULL)
		printf("null window\n");

	channels = audio_dec_ctx->channels;
	sampq = new SampleQueue(channels);
	audio_dev_ = new CSDLARender();
	audio_dev_->Init(1024, audio_dec_ctx->sample_rate, channels);
	audio_dev_->SetAudioCallBack(SDLAudioCallback, 0);
	audio_dev_->Start();
	std::thread video_render_thread(VideoRenderThread);
	std::thread vdt(VideoDecodeThread);
	std::thread adt(AudioDecodeThread);
	std::thread rt(RecvThread);

	


	SDL_Event ev;
	bool quit = false;
	while (!quit && SDL_WaitEvent(&ev) != 0) {
		// check event type
		switch (ev.type) {
		case SDL_QUIT:
			quit = true;
			break;
		case SDL_KEYDOWN:
			// test keycode
			switch (ev.key.keysym.sym) {
			case SDLK_w:
				break;
			case SDLK_s:
				break;
				// etc
			}
			break;
		case SDL_MOUSEBUTTONUP:
			// test button
			switch (ev.button.button) {
			case SDL_BUTTON_LEFT:
				break;
			case SDL_BUTTON_RIGHT:
				break;
			case SDL_BUTTON_X1:
				break;
				// etc
			}
		}
	}
	return 0;
}