#ifndef SDL_A_RENDER_H
#define SDL_A_RENDER_H
extern "C"{
#include "sdl2/SDL.h"
}

typedef void (SDL_AUDIO_CALLBACK)(void *udata,uint8_t *stream,int len);


// ����SDL �ӿ�
class CSDLARender
{
public:
	CSDLARender(void);
	~CSDLARender(void);

public:
	bool Init(int samples, int sample_rate, int channels);
	bool Start();
	bool Stop();

	void SetAudioCallBack(SDL_AUDIO_CALLBACK func, void *param);

private:
	SDL_AudioSpec		audio_spec_;
	SDL_AudioDeviceID   dev_;


};

#endif