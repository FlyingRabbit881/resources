#ifndef D3D_RENDER_H
#define D3D_RENDER_H
#include <Windows.h>
#include <d3d9.h>
//#include <d3dx9.h>
#include <vector>
#include <string>
#include <mutex>
extern "C" {
#include "libavutil/frame.h"
}
class D3DRender
{
private:
	struct SwapChain
	{
		IDirect3DSwapChain9*	d3d_swap_chain;
		HWND			        hwnd;
		RECT                    display_rect;
		bool                    need_clearing;
		int					    flag;         //0 ,2 hide, 1 show, -1 to be deleted

	};
public:
	D3DRender();
	bool Initialize(HWND hWnd);
	~D3DRender();
	bool UpdateFrame(HWND hwnd, int width, int height, BYTE* yuv_buffer);
	void CorrectDisplayRect( float ratio, RECT* rect);
	void SetDisplayRect(HWND hwnd, RECT *rect);
	bool AddPreviewWindow(HWND hwnd, bool show_flag);
	bool DelPreviewWindow(HWND hwnd);
	RECT GetDisplayRect(HWND hwnd);
	void Draw();
	void SwapChainDraw();
	bool UpdateFrame(int width, int height, BYTE* yuv_buffer);
	bool UpdateFrame(AVFrame* pic);
	bool DrawPicture(int width, int height, BYTE* yuv_buffer);
	bool DrawPicture(AVFrame* pic);
	void SetShowPreviewFlag( HWND hwnd, bool show_flag);
	bool ScreenShot(const std::string &filename);

private:
	bool InitD3D();
	void DeInitD3D();
	bool CreateD3DDevice();
	bool IsDeviceLost();
	void OnLostDevice();
	bool OnResetDevice();
private:
	HWND					show_hwnd_;
	IDirect3DDevice9*       d3ddev_;
	IDirect3D9*             d3dobj_;
	D3DPRESENT_PARAMETERS   d3dpp_;
	
	std::vector<SwapChain*> swap_chain_list_;
	int					 width_;
	int					 height_;
	IDirect3DSurface9*   surface_;
	std::mutex               mutex_;
};


#endif