
#include "SDLARender.h"
#include  <cstdio>

CSDLARender::CSDLARender(void)
	:audio_spec_()
	,dev_(0)
{
	
	
	
	
}


CSDLARender::~CSDLARender(void)
{

}

bool CSDLARender::Init(int samples, int sample_rate, int channels)
{

	audio_spec_.freq = sample_rate;
	audio_spec_.format = AUDIO_S16SYS;
	audio_spec_.channels = channels;
	audio_spec_.silence = 0;
	audio_spec_.samples = samples;

	if(SDL_Init(SDL_INIT_AUDIO | SDL_INIT_TIMER))
	{  
		printf("Could not initialize SDL - %s\n.", SDL_GetError());
	}
		

	return true;
}


void CSDLARender::SetAudioCallBack(SDL_AUDIO_CALLBACK func, void *param)
{
	audio_spec_.callback = func;
	audio_spec_.userdata = param;
}

bool CSDLARender::Start()
{

	SDL_AudioSpec have;
	
	dev_ = SDL_OpenAudioDevice(NULL, 0, &audio_spec_, &have, SDL_AUDIO_ALLOW_ANY_CHANGE);
	if (dev_ == 0)
	{
		printf("Can't open audio -%s.\n",SDL_GetError());
		return false;
	}

	SDL_PauseAudioDevice(dev_, 0);


	return true;
}
bool CSDLARender::Stop()
{

	if (dev_ > 1)
	{
		SDL_PauseAudioDevice(dev_, 1);
		SDL_CloseAudioDevice(dev_);
		dev_ = 0;
	}

	return true;
}


