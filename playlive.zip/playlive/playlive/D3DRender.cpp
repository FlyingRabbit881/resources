
#include "D3DRender.h"
//#include "d3dUtil.h"
#define ReleaseCOM(x) { if(x){ x->Release();x = 0; } }
D3DRender::D3DRender():d3dobj_(NULL),d3ddev_(NULL), surface_(0), width_(0), height_(0)
{
	
}

bool D3DRender::Initialize(HWND hWnd)
{
	show_hwnd_ = hWnd;
	
	if (!InitD3D())
		return false;
	

	IDirect3DSwapChain9*	main_swap_chain = NULL;
	if(FAILED(d3ddev_->GetSwapChain(0, &main_swap_chain)))
		return false;
	SwapChain *p_swap_chain = new SwapChain;
	p_swap_chain->d3d_swap_chain = main_swap_chain;
	p_swap_chain->hwnd = hWnd;
	p_swap_chain->flag = 1;
	swap_chain_list_.push_back(p_swap_chain);

	return true;
}
D3DRender::~D3DRender()
{
	DeInitD3D();

	ReleaseCOM(surface_);

	for(size_t i = 0; i < swap_chain_list_.size(); i++)
	{
		ReleaseCOM(swap_chain_list_[i]->d3d_swap_chain);
		delete swap_chain_list_[i];
	}
	swap_chain_list_.clear();
}

void D3DRender::CorrectDisplayRect( float ratio, RECT* rect)
{
	int grid_width = rect->right - rect->left;
	int grid_height = rect->bottom - rect->top;
	int width, height = grid_height;
	if( grid_height < grid_width * ratio)
	{
		width = (int)(grid_height/ratio);
	}
	else
	{
		width = grid_width;
	}
	RECT rc = { rect->left + (grid_width - width)/2, rect->top + (height - (int)(width * ratio))/2,  rect->right - (grid_width - width)/2  , rect->bottom - (height - (int)(width * ratio))/2};
	SetRect(rect, rc.left, rc.top, rc.right, rc.bottom);
}
#if 0
bool D3DRender::CreateD3DDevice()
{
	D3DDEVTYPE devType = D3DDEVTYPE_HAL;
	DWORD requestedVP = D3DCREATE_HARDWARE_VERTEXPROCESSING;

    d3dobj_ = Direct3DCreate9(D3D_SDK_VERSION);
	if( !d3dobj_ )
	{
		return false;
	}
	
	HRESULT result;
#if 0
	result = d3dobj_->CheckDeviceFormatConversion( D3DADAPTER_DEFAULT , D3DDEVTYPE_HAL, (D3DFORMAT)MAKEFOURCC('Y', 'V', '1', '2'), D3DFMT_X8R8G8B8);  
	if(FAILED(result))
	{
		MessageBox(NULL, L"kk", L"kk", MB_OK);
		return false;
	}

	D3DDISPLAYMODE mode;
	d3dobj_->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &mode);
	HR(d3dobj_->CheckDeviceType(D3DADAPTER_DEFAULT, devType, mode.Format, mode.Format, true));
	HR(d3dobj_->CheckDeviceType(D3DADAPTER_DEFAULT, devType, D3DFMT_X8R8G8B8, D3DFMT_X8R8G8B8, false));

	D3DCAPS9 caps;
	HR(d3dobj_->GetDeviceCaps(D3DADAPTER_DEFAULT, devType, &caps));

	DWORD devBehaviorFlags = 0;
	if( caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT )
		devBehaviorFlags |= requestedVP;
	else
		devBehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	if( caps.DevCaps & D3DDEVCAPS_PUREDEVICE &&
		devBehaviorFlags & D3DCREATE_HARDWARE_VERTEXPROCESSING)
			devBehaviorFlags |= D3DCREATE_PUREDEVICE;
#endif

	ZeroMemory( &d3dpp_, sizeof(d3dpp_) );  


	d3dpp_.BackBufferWidth            = 0; 
	d3dpp_.BackBufferHeight           = 0;
	d3dpp_.BackBufferFormat           = D3DFMT_UNKNOWN;
	d3dpp_.BackBufferCount            = 1;
	d3dpp_.MultiSampleType            = D3DMULTISAMPLE_NONE;
//	d3dpp_.MultiSampleQuality         = 0;
	d3dpp_.SwapEffect                 = D3DSWAPEFFECT_DISCARD; 
	d3dpp_.hDeviceWindow              = show_hwnd_;
	d3dpp_.Windowed                   = TRUE;
	d3dpp_.EnableAutoDepthStencil     = FALSE;
	d3dpp_.Flags                      = D3DPRESENTFLAG_VIDEO;
	//d3dpp_.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	d3dpp_.PresentationInterval       = D3DPRESENT_INTERVAL_DEFAULT;

	result = d3dobj_->CreateDevice(
		D3DADAPTER_DEFAULT, // primary adapter
		D3DDEVTYPE_HAL,           // device type
		NULL,          // window associated with device
		D3DCREATE_SOFTWARE_VERTEXPROCESSING|D3DCREATE_MULTITHREADED,   // vertex processing
	    &d3dpp_,            // present parameters
	    &d3ddev_);      // return created device

	if(FAILED(result))
	{
		return false;
	}
	return true;
}
#else
bool D3DRender::CreateD3DDevice()     //parameters from VLC
{
	UINT AdapterToUse = D3DADAPTER_DEFAULT;
    D3DDEVTYPE DeviceType = D3DDEVTYPE_HAL;

    d3dobj_ = Direct3DCreate9(D3D_SDK_VERSION);
	if( !d3dobj_ )
	{
		return false;
	}
	
	HRESULT result;
	/*
    ** Get the current desktop display mode, so we can set up a back
    ** buffer of the same format
    */
    D3DDISPLAYMODE d3ddm;
    HRESULT hr = d3dobj_->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm);
    if (FAILED(hr)) {
       printf( "Could not read adapter display mode. (hr=0x%lX)", hr);
       return false;
    }

    /* Set up the structure used to create the D3DDevice. */
    D3DPRESENT_PARAMETERS *d3dpp = &d3dpp_;
    ZeroMemory(d3dpp, sizeof(D3DPRESENT_PARAMETERS));
    d3dpp->Flags                  = D3DPRESENTFLAG_VIDEO;
    d3dpp->Windowed               = TRUE;
    d3dpp->hDeviceWindow          = show_hwnd_;
	d3dpp->BackBufferWidth        = max((unsigned int)GetSystemMetrics(SM_CXVIRTUALSCREEN), d3ddm.Width)/*0*/;
    d3dpp->BackBufferHeight       = max((unsigned int)GetSystemMetrics(SM_CYVIRTUALSCREEN), d3ddm.Height)/*0*/;
    d3dpp->SwapEffect             = D3DSWAPEFFECT_COPY;
    d3dpp->MultiSampleType        = D3DMULTISAMPLE_NONE;
    d3dpp->PresentationInterval   = D3DPRESENT_INTERVAL_DEFAULT;
    d3dpp->BackBufferFormat       = d3ddm.Format;
    d3dpp->BackBufferCount        = 1;
    d3dpp->EnableAutoDepthStencil = FALSE;


	D3DADAPTER_IDENTIFIER9 d3dai;
    if (FAILED(d3dobj_->GetAdapterIdentifier(AdapterToUse,0, &d3dai))) {
        printf("IDirect3D9_GetAdapterIdentifier failed");
    } else {
        printf( "Direct3d Device: %s %lu %lu %lu", d3dai.Description,
                d3dai.VendorId, d3dai.DeviceId, d3dai.Revision );
    }

	result = d3dobj_->CreateDevice(
		AdapterToUse, 
		DeviceType,      
		show_hwnd_,          // window associated with device
		D3DCREATE_SOFTWARE_VERTEXPROCESSING|D3DCREATE_MULTITHREADED,   // vertex processing
	    &d3dpp_,            // present parameters
	    &d3ddev_);      // return created device

	if(FAILED(result))
	{
		return false;
	}
	return true;
}
#endif

bool D3DRender::InitD3D()
{
	if(!CreateD3DDevice())
		return false;

	return true;
}
void D3DRender::DeInitD3D()
{
	ReleaseCOM(d3ddev_);
	ReleaseCOM(d3dobj_);
}
bool D3DRender::IsDeviceLost()
{
	// Get the state of the graphics device.
	HRESULT hr = d3ddev_->TestCooperativeLevel();

	// If the device is lost and cannot be reset yet then
	// sleep for a bit and we'll try again on the next 
	// message loop cycle.
	if( hr == D3DERR_DEVICELOST )
	{
		Sleep(20);
		return true;
	}
	// Driver error, exit.
	else if( hr == D3DERR_DRIVERINTERNALERROR )
	{
		MessageBox(0, "Internal Driver Error...Exiting", 0, 0);
		return true;
	}
	// The device is lost but we can reset and restore it.
	else if( hr == D3DERR_DEVICENOTRESET )
	{
		OnLostDevice();
	    d3ddev_->Reset(&d3dpp_);
		OnResetDevice();
		return true;
	}
	else
		return false;
}
void D3DRender::OnLostDevice()
{
	ReleaseCOM(surface_);
	for(size_t i = 0; i < swap_chain_list_.size(); i++)
	{
		ReleaseCOM(swap_chain_list_[i]->d3d_swap_chain);
	}
}

bool D3DRender::OnResetDevice()
{
	HRESULT result;
	result = d3ddev_->CreateOffscreenPlainSurface(width_, height_ ,(D3DFORMAT)MAKEFOURCC('Y','V','1','2'), D3DPOOL_DEFAULT,&surface_,NULL);
	if(FAILED(result))
	{
		return false;
	}
	d3ddev_->ColorFill(surface_, NULL, D3DCOLOR_ARGB(0xFF, 0, 0, 0));
	//get main swap chain
	result = d3ddev_->GetSwapChain(0, &swap_chain_list_[0]->d3d_swap_chain);
	if(FAILED(result))
	{
		return false;
	}
	for(size_t i = 1; i < swap_chain_list_.size(); i++)
	{
		D3DPRESENT_PARAMETERS d3dpp; 
		ZeroMemory( &d3dpp, sizeof(d3dpp) );
		d3dpp.Windowed = TRUE;
		d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
		d3dpp.hDeviceWindow= swap_chain_list_[i]->hwnd;
		result = d3ddev_->CreateAdditionalSwapChain(&d3dpp, &swap_chain_list_[i]->d3d_swap_chain);
		if(FAILED(result))
		{
			return false;
		}
	}

	return true;
}

bool D3DRender::UpdateFrame(int width, int height, BYTE* yuv_buffer)
{
	HRESULT result;
	if(width != width_ || height != height_)
	{
		width_ = width;
		height_ = height;
		ReleaseCOM(surface_);
		result = d3ddev_->CreateOffscreenPlainSurface(width_, height_ ,(D3DFORMAT)MAKEFOURCC('Y','V','1','2'), D3DPOOL_DEFAULT,&surface_,NULL);
		if(FAILED(result))
		{
			return false;
		}
		d3ddev_->ColorFill(surface_, NULL, D3DCOLOR_ARGB(0xFF, 0, 0, 0));
		for (size_t i = 0; i < swap_chain_list_.size(); i++)
		{
			RECT rc;
			GetClientRect(swap_chain_list_[i]->hwnd, &rc);
			CorrectDisplayRect((float)height_/width_, &rc);
			swap_chain_list_[i]->display_rect = rc;
			swap_chain_list_[i]->need_clearing = true;
		}

	}
	D3DLOCKED_RECT lrect ;
	result = surface_->LockRect(&lrect,NULL,0);
	if(FAILED(result))
	{
		return false;
	}
	BYTE *p_temp = yuv_buffer;
	int chroma_pitch =(lrect.Pitch)/2;
	int pitch[3] = {
		lrect.Pitch,
		chroma_pitch,
		chroma_pitch,
	};
	BYTE *plane[3] = {
		(BYTE*)lrect.pBits,
		(BYTE*)lrect.pBits + pitch[0] * height_,
		(BYTE*)lrect.pBits + pitch[0] * height_ + pitch[1] * height_ / 2,
	};

	for(int i=0; i<height_; i++)
	{
		BYTE *new_line = plane[0] + pitch[0] * i;
		memcpy(new_line, p_temp, width_);
		p_temp += width_;
	}

	for(int i=0; i<height_/2; i++)
	{
		BYTE *new_line = plane[2] + pitch[2] * i;
		memcpy(new_line, p_temp, width_/2);
		p_temp += width_/2;
	}

	for(int i=0; i<height_/2; i++)
	{
		BYTE *new_line = plane[1] + pitch[1] * i;
		memcpy(new_line, p_temp, width_/2);
		p_temp += width_/2;
	}

	result = surface_->UnlockRect();
	if(FAILED(result))
	{
		return false;
	}
	return true;
}

bool D3DRender::UpdateFrame(AVFrame* pic)
{
	HRESULT result;
	if (pic->width != width_ || pic->height != height_)
	{
		width_ = pic->width;
		height_ = pic->height;
		ReleaseCOM(surface_);
		result = d3ddev_->CreateOffscreenPlainSurface(width_, height_, (D3DFORMAT)MAKEFOURCC('Y', 'V', '1', '2'), D3DPOOL_DEFAULT, &surface_, NULL);
		if (FAILED(result))
		{
			return false;
		}
		d3ddev_->ColorFill(surface_, NULL, D3DCOLOR_ARGB(0xFF, 0, 0, 0));
		for (size_t i = 0; i < swap_chain_list_.size(); i++)
		{
			RECT rc;
			GetClientRect(swap_chain_list_[i]->hwnd, &rc);
			CorrectDisplayRect((float)height_ / width_, &rc);
			swap_chain_list_[i]->display_rect = rc;
			swap_chain_list_[i]->need_clearing = true;
		}

	}
	D3DLOCKED_RECT lrect;
	result = surface_->LockRect(&lrect, NULL, 0);
	if (FAILED(result))
	{
		return false;
	}
	BYTE *p_temp = pic->data[0];
	int chroma_pitch = (lrect.Pitch) / 2;
	int pitch[3] = {
		lrect.Pitch,
		chroma_pitch,
		chroma_pitch,
	};
	BYTE *plane[3] = {
		(BYTE*)lrect.pBits,
		(BYTE*)lrect.pBits + pitch[0] * height_,
		(BYTE*)lrect.pBits + pitch[0] * height_ + pitch[1] * height_ / 2,
	};

	for (int i = 0; i < height_; i++)
	{
		BYTE *new_line = plane[0] + pitch[0] * i;
		memcpy(new_line, p_temp, width_);
		p_temp += pic->linesize[0];
	}

	p_temp = pic->data[1];
	for (int i = 0; i < height_ / 2; i++)
	{
		BYTE *new_line = plane[2] + pitch[2] * i;
		memcpy(new_line, p_temp, width_ / 2);
		p_temp += pic->linesize[1];
	}

	p_temp = pic->data[2];
	for (int i = 0; i < height_ / 2; i++)
	{
		BYTE *new_line = plane[1] + pitch[1] * i;
		memcpy(new_line, p_temp, width_ / 2);
		p_temp += pic->linesize[2];
	}

	result = surface_->UnlockRect();
	if (FAILED(result))
	{
		return false;
	}
	return true;

}

void D3DRender::SwapChainDraw()
{
	for(size_t i=0; i < swap_chain_list_.size(); i++)
	{
		if( swap_chain_list_[i]->flag == 1)
		{
			IDirect3DSwapChain9* swap_chain = swap_chain_list_[i]->d3d_swap_chain;
			if(swap_chain_list_[i]->need_clearing)
			{
				d3ddev_->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
				swap_chain_list_[i]->need_clearing = false;
				//d3ddev_->BeginScene();
			}
			LPDIRECT3DSURFACE9 back_buffer = NULL;
			HRESULT hr = swap_chain->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &back_buffer);
			hr = d3ddev_->SetRenderTarget(0, back_buffer);
		
			RECT rect = swap_chain_list_[i]->display_rect;
			 hr = d3ddev_->StretchRect( surface_, NULL, back_buffer, /*&rect*/ NULL, D3DTEXF_LINEAR );
			if (hr == D3D_OK)
			{
				//MessageBox(NULL, L"stretchrect", L"", MB_OK);
			}
			else if (hr == D3DERR_INVALIDCALL)
			{
			/*	char tmp[1024];
				sprintf(tmp, "%d %d %d %d", rect.top, rect.left, rect.right, rect.bottom);
				MessageBoxA(NULL, tmp, "D3DERR_INVALIDCALL", MB_OK);*/
			}
		
			//d3ddev_->EndScene();
			swap_chain->Present(0, 0, 0, 0, 0);
			back_buffer->Release();
			
		}
		else if( swap_chain_list_[i]->flag == 0)
		{
			IDirect3DSwapChain9* swap_chain = swap_chain_list_[i]->d3d_swap_chain;
			LPDIRECT3DSURFACE9 back_buffer = NULL;
			swap_chain->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &back_buffer);
			d3ddev_->SetRenderTarget(0, back_buffer);
			d3ddev_->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
			back_buffer->Release();
			swap_chain->Present(0, 0, 0, 0, 0);

			swap_chain_list_[i]->flag = 2;
		}
	}
}
void D3DRender::Draw()
{
	if(IsDeviceLost())
		return;

	
	SwapChainDraw();
}
bool D3DRender::DrawPicture(int width, int height, BYTE* yuv_buffer)
{
	if (UpdateFrame(width, height, yuv_buffer))
	{
		Draw();
		return true;
	}
	return false;
}

bool D3DRender::DrawPicture(AVFrame* pic)
{
	if (UpdateFrame(pic))
	{
		Draw();
		return true;
	}
	return false;
}



bool D3DRender::ScreenShot(const std::string &filename)
{
	
	return true;
}
