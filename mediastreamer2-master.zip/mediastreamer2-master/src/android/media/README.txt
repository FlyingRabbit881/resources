This folder contains files header from android ndk. It's used for compile with older version of android 6 to uses mediacodec functions.

