
#include "FrameQueue.h"
#include <stdio.h>

FrameQueue::FrameQueue(size_t capacity)
{
	p_buffer_ = new CircularBuffer(capacity);
	abort_request_ = false;

}
FrameQueue::~FrameQueue()
{
	delete p_buffer_;
}

bool FrameQueue::put(void* data, size_t size, int64_t pts, int w, int h)
{
	FrameInfo info;
	int total_size = sizeof(info) + size;
	info.pts = pts;
	info.size = size;
	info.width = w;
	info.height = h;
	{
		std::lock_guard<std::mutex> lk(mutex_);
		if (p_buffer_->available() < total_size)
			return false;

		p_buffer_->write((const char*)&info, sizeof(info));
		p_buffer_->write((const char*)data, size);
	}

	cond_.notify_one();

	return true;
}




bool FrameQueue::get(void *data, size_t *size, int64_t *pts, int *w, int *h)
{
	FrameInfo info;
	{
		std::unique_lock <std::mutex> lk(mutex_);
		cond_.wait(lk, [this]() { return !empty(); });
		p_buffer_->read((char*)&info, sizeof(info));
		p_buffer_->read((char*)data, info.size);
	}

	*size = info.size;
	*pts = info.pts;
	*w = info.width;
	*h = info.height;
	
	return true;
}

bool FrameQueue::empty()
{
	return p_buffer_->size() == 0;
}
void FrameQueue::flush()
{
}

void FrameQueue::reset()
{
	std::lock_guard<std::mutex> lk(mutex_);
	p_buffer_->reset();
	abort_request_ = false;
}

void FrameQueue::abort()
{
	std::lock_guard<std::mutex> lk(mutex_);
	abort_request_ = true;
	cond_.notify_one();
}