#include <iostream>
#include <thread>
#include <mutex>
#include <queue>
#include "FrameQueue.h"
#include "D3DRender.h"

extern "C" {
#include "sdl2/SDL.h"
#include "libavcodec/avcodec.h"
#include "libavutil/opt.h"
#include "libavutil/time.h"
#include "libavutil/frame.h"
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
#include <libavformat/avformat.h>
};
#undef main

const char* url = "rtmp://localhost/live/stream";
static AVFormatContext *fmt_ctx = NULL;
static AVCodecContext *video_dec_ctx = NULL, *audio_dec_ctx;
static int width, height;
int video_stream_index = -1;
HWND hwnd_;
class PacketQueue
{
public:
	void Enqueue(AVPacket* pkt)
	{
		AVPacket* tmp = av_packet_alloc();
		av_packet_ref(tmp, pkt);
		{
			std::lock_guard<std::mutex> lk(mutex_);
			pkts_.push(tmp);
		}
		cv_.notify_one();
	}
	AVPacket* Dequeue()
	{
		std::unique_lock <std::mutex> lk(mutex_);
		cv_.wait(lk, [this]() { return !pkts_.empty(); });
		AVPacket* pkt = pkts_.front();
		pkts_.pop();
		return pkt;
	}
private:
	std::queue<AVPacket*> pkts_;
	std::mutex mutex_;
	std::condition_variable cv_;
};

PacketQueue pkt_q;
FrameQueue frame_q((sizeof(FrameQueue::FrameInfo) + 1920 * 1200 * 3 / 2) * 5); //5 pics

void RecvThread()
{
	AVPacket pkt;
	av_init_packet(&pkt);
	pkt.data = NULL;
	pkt.size = 0;
	/* read frames from the file */
	while (av_read_frame(fmt_ctx, &pkt) >= 0) {
		// check if the packet belongs to a stream we are interested in, otherwise
		// skip it
		if (pkt.stream_index == video_stream_index)
		{
			pkt_q.Enqueue(&pkt);
		}
		av_packet_unref(&pkt);
	}


}
void CopyYUVtoBuffer(uint8_t *dst, uint8_t *src[3], int src_pitch[3], unsigned width, unsigned height)
{
	unsigned int i;
	uint8_t *dstU, *dstV;
	dstU = dst + width * height;
	dstV = dstU + width * height / 4;
	unsigned int heithtUV, widthUV;
	heithtUV = height / 2;
	widthUV = width / 2;

	for (i = 0; i < height; i++) //Y
	{
		memcpy(dst + i * width, src[0] + i * src_pitch[0], width);
	}

	for (i = 0; i < heithtUV; i++) //U
	{
		memcpy(dstU + i * widthUV, src[1] + i * src_pitch[1], widthUV);
	}

	for (i = 0; i < heithtUV; i++) //V
	{
		memcpy(dstV + i * widthUV, src[2] + i * src_pitch[2], widthUV);
	}

}
int DecodeThread()
{  
	uint8_t* pkt_buf = new uint8_t[1920 * 1200 * 3 / 2];
	int ret;
	AVFrame* frame = av_frame_alloc();
	while (1)
	{
		AVPacket* pkt = pkt_q.Dequeue();
		// submit the packet to the decoder
		ret = avcodec_send_packet(video_dec_ctx, pkt);
		if (ret < 0) {
			fprintf(stderr, "Error submitting a packet for decoding");
		}

		// get all the available frames from the decoder
		while (ret >= 0) {
			ret = avcodec_receive_frame(video_dec_ctx, frame);
			if (ret < 0) {
				// those two return values are special and mean there is no output
				// frame available, but there were no errors during decoding
				if (ret == AVERROR_EOF || ret == AVERROR(EAGAIN))
					break;

				fprintf(stderr, "Error during decoding");
				break;
			}
			int64_t frame_pts = frame->best_effort_timestamp;
			CopyYUVtoBuffer(pkt_buf, frame->data, frame->linesize, frame->width, frame->height);
			bool r = frame_q.put(pkt_buf, frame->width * frame->height * 3 / 2, frame_pts, frame->width, frame->height);
			if (r == false)
				printf("frame queue is full\n");

			av_frame_unref(frame);
		}
		av_packet_free(&pkt);
	}
}
int RenderThread()
{
	D3DRender* renderer_ = new D3DRender();
	if (!renderer_->Initialize(hwnd_))
		return -1;


	int64_t pts = AV_NOPTS_VALUE;
	size_t size;
	int w, h;
	uint8_t *yuv_buffer = new uint8_t[1920 * 1200 * 3 / 2];
	for (;;)
	{
		frame_q.get(yuv_buffer, &size, &pts, &w, &h);

		bool r = renderer_->DrawPicture(w, h, yuv_buffer);

		pts = AV_NOPTS_VALUE;

	}
	delete[] yuv_buffer;
	delete renderer_;

}

int main()
{
	SDL_Window *window;                    // ����SDL_Windowָ��
	SDL_Init(SDL_INIT_VIDEO);              // ��ʼ��SDL2ϵͳ
	// ����һ��Ӧ�ô���
	window = SDL_CreateWindow(
		"Video",                  // ����title
		SDL_WINDOWPOS_UNDEFINED,           // x
		SDL_WINDOWPOS_UNDEFINED,           // y
		1280,                               // ��
		720,                               // ��
		SDL_WINDOW_OPENGL                  // flags - see below
	);
	// ��鴰���Ƿ񴴽��ɹ���������ɹ�window ΪNULL
	if (window == NULL) {
		// �������û�д����ɹ�������ĳ����Ѿ�û��ִ�еı�Ҫ�ˡ�
		printf("Could not create window: %s\n", SDL_GetError());
		return 1;
	}
	hwnd_ = FindWindow(NULL, "Video");
	if (hwnd_ == NULL)
		printf("null window\n");


	/* open input file, and allocate format context */
	if (avformat_open_input(&fmt_ctx, url, NULL, NULL) < 0) {
		fprintf(stderr, "Could not open source file %s\n", url);
		exit(1);
	}

	/* retrieve stream information */
	if (avformat_find_stream_info(fmt_ctx, NULL) < 0) {
		fprintf(stderr, "Could not find stream information\n");
		exit(1);
	}
	int ret = av_find_best_stream(fmt_ctx, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
	if (ret < 0) {
		fprintf(stderr, "Could not find %s stream in input file '%s'\n",
			av_get_media_type_string(AVMEDIA_TYPE_VIDEO), url);
		return ret;
	}
	else {
		video_stream_index = ret;
		AVStream* st = fmt_ctx->streams[video_stream_index];

		/* find decoder for the stream */
		AVCodec* dec = avcodec_find_decoder(st->codecpar->codec_id);
		if (!dec) {
			fprintf(stderr, "Failed to find %s codec\n",
				av_get_media_type_string(AVMEDIA_TYPE_VIDEO));
			return AVERROR(EINVAL);
		}

		/* Allocate a codec context for the decoder */
		video_dec_ctx = avcodec_alloc_context3(dec);

		/* Copy codec parameters from input stream to output codec context */
		if ((ret = avcodec_parameters_to_context(video_dec_ctx, st->codecpar)) < 0) {
			fprintf(stderr, "Failed to copy %s codec parameters to decoder context\n",
				av_get_media_type_string(AVMEDIA_TYPE_VIDEO));
			return ret;
		}

		/* Init the decoders */
		if ((ret = avcodec_open2(video_dec_ctx, dec, NULL)) < 0) {
			fprintf(stderr, "Failed to open %s codec\n",
				av_get_media_type_string(AVMEDIA_TYPE_VIDEO));
			return ret;
		}
	}


	std::thread render_thread(RenderThread);
	std::thread dt(DecodeThread);

	std::thread rt(RecvThread);
	
	
	SDL_Event ev;
	bool quit = false;
	while (!quit && SDL_WaitEvent(&ev) != 0) {
		// check event type
		switch (ev.type) {
		case SDL_QUIT:
			quit = true;
			break;
		case SDL_KEYDOWN:
			// test keycode
			switch (ev.key.keysym.sym) {
			case SDLK_w:
				break;
			case SDLK_s:
				break;
				// etc
			}
			break;
		case SDL_MOUSEBUTTONUP:
			// test button
			switch (ev.button.button) {
			case SDL_BUTTON_LEFT:
				break;
			case SDL_BUTTON_RIGHT:
				break;
			case SDL_BUTTON_X1:
				break;
				// etc
			}
		}
	}
	return 0;
}