#ifndef FRAME_QUEUE_H
#define FRAME_QUEUE_H
#include <Windows.h>
#include "CircularBuffer.h"
#include <stdint.h>
#include <mutex>
class FrameQueue
{
public:
	struct FrameInfo
	{
		int64_t pts;
		size_t size;
		int width;
		int height;
	};
	FrameQueue(size_t capacity);
	~FrameQueue();

	bool put(void* data, size_t size, int64_t pts, int w, int h);
	bool get(void* data, size_t *size, int64_t *pts, int *w, int *h);
	bool empty();
	void abort();
	void flush();
	void reset();
private:
	CircularBuffer *p_buffer_;
	std::mutex mutex_;
	std::condition_variable cond_;
	bool abort_request_;
};


#endif